package com.tomc.leveling;

import com.tomc.leveling.core.LevelingRegistry;
import com.tomc.leveling.core.LevelingService;
import com.tomc.leveling.data.DefinitionDataLoader;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.class_3222;
import net.minecraft.class_3264;

/**
 * 服务端事件：生命周期、数据包重载、登录/退服/重生。
 */
public final class LevelingEvents {
    private LevelingEvents() {
    }

    public static void register() {
        ServerLifecycleEvents.SERVER_STARTING.register(server ->
                LevelingRegistry.INSTANCE.store().init(server));

        ServerLifecycleEvents.SERVER_STOPPED.register(server ->
                LevelingRegistry.INSTANCE.store().invalidateAll());

        ResourceManagerHelper.get(class_3264.field_14190)
                .registerReloadListener(new DefinitionDataLoader(LevelingRegistry.INSTANCE.definitions()));

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.method_32311();
            server.execute(() -> LevelingService.INSTANCE.onPlayerJoin(player));
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            class_3222 player = handler.method_32311();
            if (player != null) {
                LevelingRegistry.INSTANCE.store().invalidate(player.method_5667());
            }
        });

        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) ->
                LevelingService.INSTANCE.onPlayerJoin(newPlayer));
    }
}
