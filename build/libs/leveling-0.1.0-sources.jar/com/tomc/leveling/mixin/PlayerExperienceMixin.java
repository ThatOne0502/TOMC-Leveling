package com.tomc.leveling.mixin;

import com.tomc.leveling.core.LevelingService;
import net.minecraft.class_1657;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 升级检测：giveExperienceLevels 正向增加经验等级时触发分发检查。
 */
@Mixin(class_1657.class)
public abstract class PlayerExperienceMixin {
    @Inject(method = "giveExperienceLevels", at = @At("RETURN"))
    private void leveling$onGiveExperienceLevels(int levels, CallbackInfo ci) {
        if (levels > 0) {
            class_1657 self = (class_1657) (Object) this;
            if (self instanceof class_3222 serverPlayer) {
                LevelingService.INSTANCE.checkDistribution(serverPlayer);
            }
        }
    }
}
