package com.tomc.leveling.data;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.tomc.leveling.Leveling;
import com.tomc.leveling.core.AttributeDefinition;
import com.tomc.leveling.core.AttributeDefinitionRegistry;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1322;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3518;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * 数据包属性定义加载器。遍历所有 data/&lt;namespace&gt;/leveling/*.json。
 * 挂到 SERVER_DATA 重载监听上：世界加载时与 /reload 时触发。
 */
public final class DefinitionDataLoader implements SimpleSynchronousResourceReloadListener {
    public static final class_2960 ID = class_2960.method_60655(Leveling.MOD_ID, "attribute_definitions");

    private final AttributeDefinitionRegistry registry;

    public DefinitionDataLoader(AttributeDefinitionRegistry registry) {
        this.registry = registry;
    }

    @Override
    public class_2960 getFabricId() {
        return ID;
    }

    @Override
    public void method_14491(class_3300 manager) {
        registry.clear();
        Map<class_2960, class_3298> resources = manager.method_14488("leveling", path -> path.method_12832().endsWith(".json"));
        for (Map.Entry<class_2960, class_3298> entry : resources.entrySet()) {
            class_2960 path = entry.getKey();
            try (InputStream in = entry.getValue().method_14482()) {
                JsonObject object = class_3518.method_15255(new InputStreamReader(in, StandardCharsets.UTF_8));
                AttributeDefinition definition = parse(path, object);
                if (definition != null) {
                    registry.put(definition.attribute(), definition, path.toString());
                }
            } catch (Exception e) {
                Leveling.LOGGER.warn("[leveling] Failed to load attribute definition {}: {}", path, e.getMessage());
                registry.addError(path.toString());
            }
        }
        Leveling.LOGGER.info("[leveling] Loaded {} attribute definition(s), {} error(s)",
                registry.all().size(), registry.getLoadErrors().size());
    }

    private AttributeDefinition parse(class_2960 path, JsonObject object) {
        String attrStr = class_3518.method_15253(object, "attribute", null);
        if (attrStr == null || attrStr.isEmpty()) {
            return fail(path, "missing 'attribute'");
        }
        class_2960 attribute = class_2960.method_12829(attrStr);
        if (attribute == null) {
            return fail(path, "invalid 'attribute': " + attrStr);
        }

        // translation_key 现为可选（display_key 成为新的主键，translation_key 作为回退）。
        String translationKey = class_3518.method_15253(object, "translation_key", null);
        String displayKey = class_3518.method_15253(object, "display_key", null);
        String descriptionKey = class_3518.method_15253(object, "description_key", null);
        Integer order = object.has("order") ? class_3518.method_15282(object, "order", 0) : null;

        int cost = class_3518.method_15282(object, "cost", 1);
        if (cost < 0) {
            return fail(path, "'cost' must be non-negative");
        }

        String opStr = class_3518.method_15253(object, "operation", null);
        class_1322.class_1323 operation = switch (opStr == null ? "" : opStr) {
            case "add_value" -> class_1322.class_1323.field_6328;
            case "add_multiplied_total" -> class_1322.class_1323.field_6331;
            default -> null;
        };
        if (operation == null) {
            return fail(path, "invalid 'operation': " + opStr);
        }

        boolean hasValuePerLevel = object.has("value_per_level");
        boolean hasValues = object.has("values");
        if (hasValuePerLevel == hasValues) {
            return fail(path, "exactly one of 'value_per_level' or 'values' is required");
        }

        double valuePerLevel = 0.0;
        double[] values = new double[0];
        if (hasValuePerLevel) {
            valuePerLevel = class_3518.method_15277(object, "value_per_level", 0.0F);
        } else {
            JsonElement element = object.get("values");
            if (!element.isJsonArray()) {
                return fail(path, "'values' must be an array");
            }
            JsonArray array = element.getAsJsonArray();
            if (array.isEmpty()) {
                return fail(path, "'values' must not be empty");
            }
            values = new double[array.size()];
            for (int i = 0; i < array.size(); i++) {
                JsonElement value = array.get(i);
                if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isNumber()) {
                    return fail(path, "'values' must contain only numbers");
                }
                values[i] = value.getAsDouble();
            }
        }

        return new AttributeDefinition(attribute, translationKey, cost, operation, valuePerLevel, values, order, displayKey, descriptionKey);
    }

    private AttributeDefinition fail(class_2960 path, String reason) {
        String message = path.toString() + " : " + reason;
        Leveling.LOGGER.warn("[leveling] Skipping attribute definition: {}", message);
        registry.addError(message);
        return null;
    }
}
