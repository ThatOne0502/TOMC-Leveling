package com.tomc.leveling.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.tomc.leveling.core.AttributeDefinition;
import com.tomc.leveling.core.LevelingRegistry;
import com.tomc.leveling.core.LevelingService;
import com.tomc.leveling.data.PlayerLevelingData;
import com.tomc.leveling.network.LevelingNetwork;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_12099;
import net.minecraft.class_1322;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import java.util.Locale;
import java.util.Map;

/**
 * /leveling point|cap 命令树，整体要求 OP（gamemaster，等级 2）权限。
 */
public final class LevelingCommand {
    private LevelingCommand() {
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(class_2170.method_9247("leveling")
                        .requires(source -> source.method_75037().hasPermission(class_12099.field_63210))
                        .then(point())
                        .then(cap())));
    }

    private static LiteralArgumentBuilder<class_2168> point() {
        return class_2170.method_9247("point")
                .then(class_2170.method_9244("target", class_2186.method_9305())
                        .then(class_2170.method_9247("set")
                                .then(class_2170.method_9244("value", IntegerArgumentType.integer())
                                        .executes(LevelingCommand::pointSet)))
                        .then(class_2170.method_9247("give")
                                .then(class_2170.method_9244("value", IntegerArgumentType.integer())
                                        .executes(LevelingCommand::pointGive)))
                        .then(class_2170.method_9247("get")
                                .executes(LevelingCommand::pointGet))
                        .then(class_2170.method_9247("clear")
                                .executes(ctx -> pointClear(ctx, -1))
                                .then(class_2170.method_9244("value", IntegerArgumentType.integer())
                                        .executes(ctx -> pointClear(ctx, IntegerArgumentType.getInteger(ctx, "value")))))
                        .then(class_2170.method_9247("reset")
                                .executes(LevelingCommand::pointReset))
                        .then(class_2170.method_9247("getspend")
                                .executes(LevelingCommand::getSpendAll)
                                .then(class_2170.method_9244("attribute", StringArgumentType.string())
                                        .executes(LevelingCommand::getSpendOne))));
    }

    private static LiteralArgumentBuilder<class_2168> cap() {
        return class_2170.method_9247("cap")
                .then(class_2170.method_9244("target", class_2186.method_9305())
                        .then(class_2170.method_9247("set")
                                .then(class_2170.method_9244("value", IntegerArgumentType.integer())
                                        .executes(LevelingCommand::capSet)))
                        .then(class_2170.method_9247("give")
                                .then(class_2170.method_9244("value", IntegerArgumentType.integer())
                                        .executes(LevelingCommand::capGive)))
                        .then(class_2170.method_9247("get")
                                .executes(LevelingCommand::capGet))
                        .then(class_2170.method_9247("clear")
                                .executes(ctx -> capClear(ctx, -1))
                                .then(class_2170.method_9244("value", IntegerArgumentType.integer())
                                        .executes(ctx -> capClear(ctx, IntegerArgumentType.getInteger(ctx, "value")))))
                        .then(class_2170.method_9247("reset")
                                .executes(LevelingCommand::capReset)));
    }

    private static int pointSet(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_3222 target = class_2186.method_9315(ctx, "target");
        int value = IntegerArgumentType.getInteger(ctx, "value");
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(target.method_5667());
        data.unspentPoints = Math.max(0, value);
        saveAndSync(target, data);
        feedback(ctx, "command.leveling.point.set", target.method_5476(), data.unspentPoints);
        return 1;
    }

    private static int pointGive(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_3222 target = class_2186.method_9315(ctx, "target");
        int value = IntegerArgumentType.getInteger(ctx, "value");
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(target.method_5667());
        data.unspentPoints = Math.max(0, data.unspentPoints + value);
        saveAndSync(target, data);
        feedback(ctx, "command.leveling.point.set", target.method_5476(), data.unspentPoints);
        return 1;
    }

    private static int pointGet(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_3222 target = class_2186.method_9315(ctx, "target");
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(target.method_5667());
        feedback(ctx, "command.leveling.point.get", target.method_5476(), data.unspentPoints);
        return 1;
    }

    private static int pointClear(CommandContext<class_2168> ctx, int amount) throws CommandSyntaxException {
        class_3222 target = class_2186.method_9315(ctx, "target");
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(target.method_5667());
        if (amount < 0) {
            data.unspentPoints = 0;
        } else {
            data.unspentPoints = Math.max(0, data.unspentPoints - amount);
        }
        saveAndSync(target, data);
        feedback(ctx, "command.leveling.point.set", target.method_5476(), data.unspentPoints);
        return 1;
    }

    private static int pointReset(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_3222 target = class_2186.method_9315(ctx, "target");
        LevelingService.INSTANCE.resetAllocations(target, false, false);
        feedback(ctx, "command.leveling.point.reset", target.method_5476());
        return 1;
    }

    private static int getSpendAll(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_3222 target = class_2186.method_9315(ctx, "target");
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(target.method_5667());
        if (data.allocations.isEmpty()) {
            feedback(ctx, "command.leveling.getspend.empty", target.method_5476());
        } else {
            for (Map.Entry<String, PlayerLevelingData.Allocation> entry : data.allocations.entrySet()) {
                sendSpendLine(ctx, entry.getKey(), entry.getValue());
            }
        }
        return 1;
    }

    private static int getSpendOne(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_3222 target = class_2186.method_9315(ctx, "target");
        String attribute = StringArgumentType.getString(ctx, "attribute");
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(target.method_5667());
        PlayerLevelingData.Allocation allocation = data.allocations.get(attribute);
        if (allocation == null) {
            feedback(ctx, "command.leveling.getspend.none", target.method_5476(), attribute);
        } else {
            sendSpendLine(ctx, attribute, allocation);
        }
        return 1;
    }

    private static void sendSpendLine(CommandContext<class_2168> ctx, String attribute, PlayerLevelingData.Allocation allocation) {
        class_2960 id = class_2960.method_12829(attribute);
        AttributeDefinition definition = id == null ? null : LevelingRegistry.INSTANCE.definitions().get(id);
        StringBuilder builder = new StringBuilder();
        builder.append(attribute).append(": levels=").append(allocation.levels).append(", spent=").append(allocation.spent);
        if (definition != null) {
            double bonus = definition.totalValue(allocation.levels);
            if (definition.operation() == class_1322.class_1323.field_6331) {
                builder.append(", bonus=+").append(String.format(Locale.ROOT, "%.1f%%", bonus * 100.0));
            } else {
                builder.append(", bonus=+").append(String.format(Locale.ROOT, "%.1f", bonus));
            }
        } else {
            builder.append(", ").append(class_2561.method_43471("command.leveling.getspend.invalid").getString());
        }
        String line = builder.toString();
        ctx.getSource().method_9226(() -> class_2561.method_43470(line), false);
    }

    private static int capSet(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_3222 target = class_2186.method_9315(ctx, "target");
        int value = IntegerArgumentType.getInteger(ctx, "value");
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(target.method_5667());
        data.highestLevel = Math.max(0, value);
        saveAndSync(target, data);
        feedback(ctx, "command.leveling.cap.set", target.method_5476(), data.highestLevel);
        return 1;
    }

    private static int capGive(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_3222 target = class_2186.method_9315(ctx, "target");
        int value = IntegerArgumentType.getInteger(ctx, "value");
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(target.method_5667());
        data.highestLevel = Math.max(0, data.highestLevel + value);
        saveAndSync(target, data);
        feedback(ctx, "command.leveling.cap.set", target.method_5476(), data.highestLevel);
        return 1;
    }

    private static int capGet(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_3222 target = class_2186.method_9315(ctx, "target");
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(target.method_5667());
        feedback(ctx, "command.leveling.cap.get", target.method_5476(), data.highestLevel);
        return 1;
    }

    private static int capClear(CommandContext<class_2168> ctx, int amount) throws CommandSyntaxException {
        class_3222 target = class_2186.method_9315(ctx, "target");
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(target.method_5667());
        if (amount < 0) {
            data.highestLevel = 0;
        } else {
            data.highestLevel = Math.max(0, data.highestLevel - amount);
        }
        saveAndSync(target, data);
        feedback(ctx, "command.leveling.cap.set", target.method_5476(), data.highestLevel);
        return 1;
    }

    private static int capReset(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_3222 target = class_2186.method_9315(ctx, "target");
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(target.method_5667());
        data.highestLevel = 0;
        saveAndSync(target, data);
        feedback(ctx, "command.leveling.cap.set", target.method_5476(), data.highestLevel);
        return 1;
    }

    private static void saveAndSync(class_3222 target, PlayerLevelingData data) {
        LevelingRegistry.INSTANCE.store().save(target.method_5667(), data);
        LevelingNetwork.sendPanel(target);
    }

    private static void feedback(CommandContext<class_2168> ctx, String key, Object... args) {
        ctx.getSource().method_9226(() -> class_2561.method_43469(key, args), false);
    }
}
