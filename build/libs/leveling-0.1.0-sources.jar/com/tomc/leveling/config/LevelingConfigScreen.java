package com.tomc.leveling.config;

import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * 游戏内配置界面（经 Mod Menu 打开）。可直接修改客户端与服务端配置并保存。
 * 注意：服务端配置在多人联机时仅修改本机文件，不影响远端服务器。
 */
public class LevelingConfigScreen extends class_437 {
    private static final int[] INTERVALS = {0, 5, 10, 15, 30, 60};
    private final class_437 parent;

    public LevelingConfigScreen(class_437 parent) {
        super(class_2561.method_43471("gui.leveling.config.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int x = this.field_22789 / 2 - 155;
        int w = 310;
        int y = 42;

        method_37063(class_4185.method_46430(reminderLabel(), btn -> {
            ClientConfig.INSTANCE.reminderEnabled = !ClientConfig.INSTANCE.reminderEnabled;
            btn.method_25355(reminderLabel());
        }).method_46434(x, y, w, 20).method_46431());
        y += 26;

        method_37063(class_4185.method_46430(intervalLabel(), btn -> {
            cycleInterval();
            btn.method_25355(intervalLabel());
        }).method_46434(x, y, w, 20).method_46431());
        y += 26;

        method_37063(class_4185.method_46430(clearRecipesLabel(), btn -> {
            ServerConfig.INSTANCE.clearRecipesOnUse = !ServerConfig.INSTANCE.clearRecipesOnUse;
            btn.method_25355(clearRecipesLabel());
        }).method_46434(x, y, w, 20).method_46431());
        y += 26;

        method_37063(class_4185.method_46430(clearAdvancementsLabel(), btn -> {
            ServerConfig.INSTANCE.clearAdvancementsOnUse = !ServerConfig.INSTANCE.clearAdvancementsOnUse;
            btn.method_25355(clearAdvancementsLabel());
        }).method_46434(x, y, w, 20).method_46431());
        y += 32;

        method_37063(class_4185.method_46430(class_2561.method_43471("gui.done"), btn -> {
            ClientConfig.INSTANCE.save();
            ServerConfig.INSTANCE.save();
            if (this.field_22787 != null) {
                this.field_22787.method_1507(this.parent);
            }
        }).method_46434(x, y, w, 20).method_46431());
    }

    private void cycleInterval() {
        int current = ClientConfig.INSTANCE.reminderIntervalSeconds;
        int nextIndex = 0;
        for (int i = 0; i < INTERVALS.length; i++) {
            if (INTERVALS[i] == current) {
                nextIndex = (i + 1) % INTERVALS.length;
                break;
            }
        }
        ClientConfig.INSTANCE.reminderIntervalSeconds = INTERVALS[nextIndex];
    }

    private class_2561 reminderLabel() {
        return class_2561.method_43469("gui.leveling.config.reminder_enabled", onOff(ClientConfig.INSTANCE.reminderEnabled));
    }

    private class_2561 intervalLabel() {
        return class_2561.method_43469("gui.leveling.config.interval", ClientConfig.INSTANCE.reminderIntervalSeconds);
    }

    private class_2561 clearRecipesLabel() {
        return class_2561.method_43469("gui.leveling.config.clear_recipes", onOff(ServerConfig.INSTANCE.clearRecipesOnUse));
    }

    private class_2561 clearAdvancementsLabel() {
        return class_2561.method_43469("gui.leveling.config.clear_advancements", onOff(ServerConfig.INSTANCE.clearAdvancementsOnUse));
    }

    private class_2561 onOff(boolean value) {
        return class_2561.method_43471(value ? "gui.leveling.config.on" : "gui.leveling.config.off");
    }
}
