package com.tomc.leveling.item;

import com.tomc.leveling.core.LevelingService;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_3222;

/**
 * 孟婆汤：满饥饿可食，食用时长约为普通食物的 3 倍（约 96 tick），
 * 使用后返还一个碗并触发属性点重置。
 */
public class MengPoSoupItem extends class_1792 {
    public MengPoSoupItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public int method_7881(class_1799 stack, class_1309 entity) {
        return 96;
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 level, class_1309 entity) {
        if (!level.method_8608() && entity instanceof class_3222 player) {
            LevelingService.INSTANCE.applyMengPoSoup(player);
        }
        return new class_1799(class_1802.field_8428);
    }
}
