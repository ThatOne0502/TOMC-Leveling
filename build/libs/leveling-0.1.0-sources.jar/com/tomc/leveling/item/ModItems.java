package com.tomc.leveling.item;

import com.tomc.leveling.Leveling;
import java.util.function.Function;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4174;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ModItems {
    public static final class_1792 MENGPO_SOUP = register(
            "mengpo_soup",
            MengPoSoupItem::new,
            new class_1792.class_1793()
                    .method_7889(1)
                    .method_19265(new class_4174.class_4175()
                            .method_19238(0)
                            .method_19237(0.0F)
                            .method_19240()
                            .method_19242())
    );

    private ModItems() {
    }

    private static class_1792 register(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 props) {
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(Leveling.MOD_ID, name));
        class_1792 item = factory.apply(props.method_63686(key));
        class_2378.method_39197(class_7923.field_41178, key, item);
        return item;
    }

    /** 在 onInitialize 中调用，触发本类的静态初始化完成物品注册。 */
    public static void register() {
    }
}
