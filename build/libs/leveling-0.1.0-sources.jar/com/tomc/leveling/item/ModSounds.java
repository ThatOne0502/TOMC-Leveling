package com.tomc.leveling.item;

import com.tomc.leveling.Leveling;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public final class ModSounds {
    public static final class_3414 LEVELING = class_2378.method_10230(
            class_7923.field_41172,
            class_2960.method_60655(Leveling.MOD_ID, "leveling"),
            class_3414.method_47908(class_2960.method_60655(Leveling.MOD_ID, "leveling"))
    );

    private ModSounds() {
    }

    /** 在 onInitialize 中调用，触发本类静态初始化完成声音注册。 */
    public static void register() {
    }
}
