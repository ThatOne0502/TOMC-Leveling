package com.tomc.leveling;

import com.tomc.leveling.client.LevelingClientState;
import com.tomc.leveling.config.ClientConfig;
import com.tomc.leveling.network.payload.CheckPointsC2SPayload;
import com.tomc.leveling.network.payload.PanelDataS2CPayload;
import com.tomc.leveling.network.payload.ReminderS2CPayload;
import com.tomc.leveling.network.payload.RequestPanelC2SPayload;
import com.tomc.leveling.network.payload.SpendResultS2CPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1109;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3675;
import net.minecraft.class_6880;

/**
 * 客户端入口：按键、网络接收、提醒显示、周期核查、加点结果声音反馈。
 */
public class LevelingClient implements ClientModInitializer {
    private static class_304 openPanelKey;
    private static int checkTick = 0;

    @Override
    public void onInitializeClient() {
        ClientConfig.INSTANCE.load();

        class_304.class_11900 category = class_304.class_11900.method_74698(class_2960.method_60655(Leveling.MOD_ID, "main"));
        openPanelKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.leveling.open_panel",
                class_3675.class_307.field_1668,
                class_3675.field_32023,
                category
        ));

        ClientPlayNetworking.registerGlobalReceiver(PanelDataS2CPayload.ID, (payload, context) ->
                context.client().execute(() -> LevelingClientState.INSTANCE.onPanelData(payload, context.client())));

        ClientPlayNetworking.registerGlobalReceiver(ReminderS2CPayload.ID, (payload, context) ->
                context.client().execute(() -> onPointsStatus(context.client(), payload.unspentPoints())));

        ClientPlayNetworking.registerGlobalReceiver(SpendResultS2CPayload.ID, (payload, context) ->
                context.client().execute(() -> onSpendResult(context.client(), payload)));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openPanelKey.method_1436()) {
                LevelingClientState.INSTANCE.requestPanel();
                ClientPlayNetworking.send(new RequestPanelC2SPayload());
            }
            tickCheck(client);
        });
    }

    private static void onPointsStatus(class_310 client, int unspentPoints) {
        LevelingClientState.INSTANCE.onReminder(unspentPoints);
        showReminder(client, unspentPoints);
    }

    private static void showReminder(class_310 client, int unspentPoints) {
        if (!ClientConfig.INSTANCE.reminderEnabled || client.field_1724 == null || unspentPoints <= 0) {
            return;
        }
        class_2561 message = class_2561.method_43469("message.leveling.reminder", unspentPoints, openPanelKey.method_16007());
        client.field_1724.method_7353(message, true);
    }

    private static void onSpendResult(class_310 client, SpendResultS2CPayload payload) {
        if (payload.success()) {
            playUiSound(client, class_3417.field_14622);
        } else {
            playUiSound(client, class_3417.field_14624);
            if (client.field_1724 != null && payload.errorKey() != null && !payload.errorKey().isEmpty()) {
                client.field_1724.method_7353(class_2561.method_43471(payload.errorKey()), true);
            }
        }
    }

    /** 周期核查：按客户端配置周期向服务端申请数据，收到应答后由 onPointsStatus 决定是否提醒。 */
    private static void tickCheck(class_310 client) {
        ClientConfig config = ClientConfig.INSTANCE;
        if (!config.reminderEnabled || client.field_1724 == null) {
            return;
        }
        int intervalSeconds = config.reminderIntervalSeconds;
        checkTick++;
        if (intervalSeconds == 0) {
            // 常态显示：用缓存值每 tick 显示；每 1 秒轮询一次刷新缓存
            showReminder(client, LevelingClientState.INSTANCE.unspentPoints());
            if (checkTick % 20 == 0) {
                ClientPlayNetworking.send(new CheckPointsC2SPayload());
            }
        } else if (checkTick % (intervalSeconds * 20) == 0) {
            ClientPlayNetworking.send(new CheckPointsC2SPayload());
        }
    }

    private static void playUiSound(class_310 client, class_6880<class_3414> sound) {
        client.method_1483().method_4873(class_1109.method_47978(sound, 1.0F));
    }
}
