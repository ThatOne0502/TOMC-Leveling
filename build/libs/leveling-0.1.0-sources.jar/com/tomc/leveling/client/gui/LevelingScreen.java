package com.tomc.leveling.client.gui;

import com.tomc.leveling.network.payload.AllocationView;
import com.tomc.leveling.network.payload.AttributeDefView;
import com.tomc.leveling.network.payload.PanelDataS2CPayload;
import com.tomc.leveling.network.payload.SpendPointC2SPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1109;
import net.minecraft.class_11909;
import net.minecraft.class_1320;
import net.minecraft.class_1324;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * 属性升级面板：搜索框 + 可滚动列表，每行 序号 / 属性名 / 当前值 / 已投入点数 / [+] 按钮。
 */
public class LevelingScreen extends class_437 {
    private static final int ROW_HEIGHT = 24;
    private static final int LIST_TOP = 58;
    private static final int LIST_BOTTOM_MARGIN = 8;

    // 文本颜色必须带 alpha（顶层字节 0xFF），否则 1.21.11 按 alpha=0 渲染为透明。
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    private static final int COLOR_VALUE = 0xFFAAAAAA;
    private static final int COLOR_DISABLED = 0xFF666666;
    private static final int COLOR_BUTTON_ENABLED = 0xFF555555;
    private static final int COLOR_BUTTON_DISABLED = 0xFF2B2B2B;
    private static final int COLOR_SCROLL_TRACK = 0xFF1E1E1E;
    private static final int COLOR_SCROLL_THUMB = 0xFF888888;

    private static final int ORDER_COL_X = 8;
    private static final int NAME_COL_X = 34;

    private PanelDataS2CPayload data;
    private int scrollOffset = 0;
    private class_342 searchBox;

    private final int buttonWidth = 20;
    private int buttonX;
    private int valueColumnX;
    private int spentColumnX;

    public LevelingScreen(PanelDataS2CPayload data) {
        super(class_2561.method_43471("gui.leveling.title"));
        this.data = data;
    }

    public void updateData(PanelDataS2CPayload data) {
        this.data = data;
    }

    @Override
    protected void method_25426() {
        this.buttonX = this.field_22789 - 30;
        this.valueColumnX = this.field_22789 / 2;
        this.spentColumnX = this.field_22789 - 90;

        this.searchBox = new class_342(this.field_22793, 8, 34, this.field_22789 - 16, 18, class_2561.method_43471("gui.leveling.search"));
        this.searchBox.method_47404(class_2561.method_43471("gui.leveling.search"));
        this.searchBox.method_1880(100);
        this.method_37063(this.searchBox);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        super.method_25394(graphics, mouseX, mouseY, delta);
        class_327 font = this.field_22793;

        graphics.method_27535(font, class_2561.method_43469("gui.leveling.points", data.unspentPoints()), 8, 8, COLOR_TEXT);
        graphics.method_27535(font, class_2561.method_43469("gui.leveling.next_level", data.highestLevel() + 1), 8, 20, COLOR_TEXT);

        renderRows(graphics, mouseX, mouseY);
    }

    private List<AttributeDefView> filtered() {
        String query = searchBox.method_1882().trim().toLowerCase(Locale.ROOT);
        if (query.isEmpty()) {
            return data.definitions();
        }
        List<AttributeDefView> result = new ArrayList<>();
        for (AttributeDefView definition : data.definitions()) {
            if (matches(definition, query)) {
                result.add(definition);
            }
        }
        return result;
    }

    private boolean matches(AttributeDefView definition, String query) {
        if (definition.id().toString().toLowerCase(Locale.ROOT).contains(query)) {
            return true;
        }
        if (definition.order() != null && Integer.toString(definition.order()).contains(query)) {
            return true;
        }
        return displayName(definition).toLowerCase(Locale.ROOT).contains(query);
    }

    private void renderRows(class_332 graphics, int mouseX, int mouseY) {
        class_327 font = this.field_22793;
        List<AttributeDefView> definitions = filtered();
        int listBottom = this.field_22790 - LIST_BOTTOM_MARGIN;
        int visible = Math.max(0, (listBottom - LIST_TOP) / ROW_HEIGHT);
        int maxScroll = Math.max(0, definitions.size() - visible);
        if (scrollOffset > maxScroll) {
            scrollOffset = maxScroll;
        }

        Map<class_2960, AllocationView> allocationMap = new HashMap<>();
        for (AllocationView allocation : data.allocations()) {
            allocationMap.put(allocation.id(), allocation);
        }

        int y = LIST_TOP;
        for (int index = scrollOffset; index < definitions.size() && y + ROW_HEIGHT <= listBottom; index++) {
            AttributeDefView definition = definitions.get(index);

            String orderText = definition.order() == null ? "-" : Integer.toString(definition.order());
            graphics.method_25303(font, orderText, ORDER_COL_X, y + 6, COLOR_VALUE);

            String name = displayName(definition);
            String truncated = truncate(font, name, valueColumnX - NAME_COL_X - 12);
            graphics.method_25303(font, truncated, NAME_COL_X, y + 6, COLOR_TEXT);
            if (mouseX >= NAME_COL_X && mouseX <= valueColumnX && mouseY >= y && mouseY <= y + ROW_HEIGHT) {
                renderNameTooltip(graphics, definition, mouseX, mouseY);
            }

            String currentValue = String.format(Locale.ROOT, "%.2f", getCurrentValue(definition.id()));
            graphics.method_25303(font, currentValue, valueColumnX, y + 6, COLOR_VALUE);

            AllocationView allocation = allocationMap.get(definition.id());
            int spent = allocation == null ? 0 : allocation.spent();
            graphics.method_25303(font, class_2561.method_43469("gui.leveling.spent", spent).getString(), spentColumnX, y + 6, COLOR_VALUE);

            boolean canAfford = data.unspentPoints() >= definition.cost();
            graphics.method_25294(buttonX, y + 2, buttonX + buttonWidth, y + ROW_HEIGHT - 2, canAfford ? COLOR_BUTTON_ENABLED : COLOR_BUTTON_DISABLED);
            graphics.method_25300(font, "+", buttonX + buttonWidth / 2, y + 6, canAfford ? COLOR_TEXT : COLOR_DISABLED);

            if (mouseX >= buttonX && mouseX <= buttonX + buttonWidth && mouseY >= y && mouseY <= y + ROW_HEIGHT) {
                renderButtonTooltip(graphics, definition, mouseX, mouseY);
            }

            y += ROW_HEIGHT;
        }

        renderScrollbar(graphics, definitions.size(), maxScroll);
    }

    private void renderNameTooltip(class_332 graphics, AttributeDefView definition, int mouseX, int mouseY) {
        List<class_2561> lines = new ArrayList<>();
        lines.add(class_2561.method_43470(displayName(definition)));
        lines.add(class_2561.method_43470(definition.id().toString()));
        String description = descriptionText(definition);
        if (description != null) {
            lines.add(class_2561.method_43470(description));
        }
        graphics.method_51434(this.field_22793, lines, mouseX, mouseY);
    }

    private void renderButtonTooltip(class_332 graphics, AttributeDefView definition, int mouseX, int mouseY) {
        List<class_2561> lines = new ArrayList<>();
        lines.add(class_2561.method_43469("gui.leveling.cost", definition.cost()));
        String description = descriptionText(definition);
        if (description != null) {
            lines.add(class_2561.method_43470(description));
        }
        graphics.method_51434(this.field_22793, lines, mouseX, mouseY);
    }

    private void renderScrollbar(class_332 graphics, int total, int maxScroll) {
        if (maxScroll <= 0) {
            return;
        }
        int listBottom = this.field_22790 - LIST_BOTTOM_MARGIN;
        int trackHeight = listBottom - LIST_TOP;
        int visible = Math.max(1, (listBottom - LIST_TOP) / ROW_HEIGHT);
        int thumbHeight = Math.max(16, trackHeight * visible / Math.max(1, total));
        int thumbY = LIST_TOP + (int) ((trackHeight - thumbHeight) * ((double) scrollOffset / maxScroll));
        graphics.method_25294(this.field_22789 - 4, LIST_TOP, this.field_22789 - 2, listBottom, COLOR_SCROLL_TRACK);
        graphics.method_25294(this.field_22789 - 4, thumbY, this.field_22789 - 2, thumbY + thumbHeight, COLOR_SCROLL_THUMB);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        int listBottom = this.field_22790 - LIST_BOTTOM_MARGIN;
        int visible = Math.max(0, (listBottom - LIST_TOP) / ROW_HEIGHT);
        int maxScroll = Math.max(0, filtered().size() - visible);
        if (scrollY > 0) {
            scrollOffset = Math.max(0, scrollOffset - 1);
        } else if (scrollY < 0) {
            scrollOffset = Math.min(maxScroll, scrollOffset + 1);
        }
        return true;
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        if (event.method_74245() == 0) {
            double mouseX = event.comp_4798();
            double mouseY = event.comp_4799();
            List<AttributeDefView> definitions = filtered();
            int listBottom = this.field_22790 - LIST_BOTTOM_MARGIN;
            int visible = Math.max(0, (listBottom - LIST_TOP) / ROW_HEIGHT);
            int maxScroll = Math.max(0, definitions.size() - visible);
            int clampedScroll = Math.min(scrollOffset, maxScroll);

            int y = LIST_TOP;
            for (int index = clampedScroll; index < definitions.size() && y + ROW_HEIGHT <= listBottom; index++) {
                if (mouseX >= buttonX && mouseX <= buttonX + buttonWidth && mouseY >= y && mouseY <= y + ROW_HEIGHT) {
                    AttributeDefView definition = definitions.get(index);
                    if (data.unspentPoints() >= definition.cost()) {
                        playClickSound();
                        ClientPlayNetworking.send(new SpendPointC2SPayload(definition.id()));
                    }
                    return true;
                }
                y += ROW_HEIGHT;
            }
        }
        return super.method_25402(event, doubleClick);
    }

    private void playClickSound() {
        class_310.method_1551().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
    }

    /** 显示名：用 getOrDefault 拿原始翻译（不经过 String.format，避免 % 触发 Format error）。 */
    private String displayName(AttributeDefView definition) {
        if (definition.displayKey() != null && !definition.displayKey().isEmpty() && class_2477.method_10517().method_4678(definition.displayKey())) {
            return class_2477.method_10517().method_48307(definition.displayKey());
        }
        return definition.id().toString();
    }

    /** 描述：同样用 getOrDefault 拿原始翻译；键不存在返回 null。 */
    private String descriptionText(AttributeDefView definition) {
        if (definition.descriptionKey() != null && !definition.descriptionKey().isEmpty() && class_2477.method_10517().method_4678(definition.descriptionKey())) {
            return class_2477.method_10517().method_48307(definition.descriptionKey());
        }
        return null;
    }

    private double getCurrentValue(class_2960 attributeId) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            return 0.0;
        }
        class_6880<class_1320> holder = class_7923.field_41190.method_10223(attributeId).orElse(null);
        if (holder == null) {
            return 0.0;
        }
        class_1324 instance = client.field_1724.method_5996(holder);
        return instance == null ? 0.0 : instance.method_6194();
    }

    private String truncate(class_327 font, String text, int maxWidth) {
        if (font.method_1727(text) <= maxWidth) {
            return text;
        }
        String ellipsis = "...";
        int ellipsisWidth = font.method_1727(ellipsis);
        int prefixWidth = Math.max(2, maxWidth - ellipsisWidth);
        return font.method_27523(text, prefixWidth) + ellipsis;
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
