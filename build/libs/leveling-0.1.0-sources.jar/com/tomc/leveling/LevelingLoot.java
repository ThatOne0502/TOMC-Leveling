package com.tomc.leveling;

import com.tomc.leveling.item.ModItems;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.class_219;
import net.minecraft.class_39;
import net.minecraft.class_44;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_55;
import net.minecraft.class_77;
import java.util.Set;

/**
 * 孟婆汤战利品注入：废弃传送门、远古城市、下界要塞、末地城宝箱 + 试炼密室陶罐。
 * 每个目标约 30% 概率（约 3~4 个箱子找到 1 个）。
 */
public final class LevelingLoot {
    private static final Set<class_5321<class_52>> TARGETS = Set.of(
            class_39.field_24050,
            class_39.field_38438,
            class_39.field_615,
            class_39.field_274,
            class_39.field_47426
    );

    private LevelingLoot() {
    }

    public static void register() {
        LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
            if (source.isBuiltin() && TARGETS.contains(key)) {
                tableBuilder.method_336(class_55.method_347()
                        .method_352(class_44.method_32448(1.0F))
                        .method_351(class_77.method_411(ModItems.MENGPO_SOUP)
                                .method_421(class_219.method_932(0.3F))));
            }
        });
    }
}
