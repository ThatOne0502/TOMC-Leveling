package com.tomc.leveling.network;

import com.tomc.leveling.core.AttributeDefinition;
import com.tomc.leveling.core.LevelingRegistry;
import com.tomc.leveling.core.LevelingService;
import com.tomc.leveling.data.PlayerLevelingData;
import com.tomc.leveling.network.payload.AllocationView;
import com.tomc.leveling.network.payload.AttributeDefView;
import com.tomc.leveling.network.payload.CheckPointsC2SPayload;
import com.tomc.leveling.network.payload.PanelDataS2CPayload;
import com.tomc.leveling.network.payload.ReminderS2CPayload;
import com.tomc.leveling.network.payload.RequestPanelC2SPayload;
import com.tomc.leveling.network.payload.SpendPointC2SPayload;
import com.tomc.leveling.network.payload.SpendResultS2CPayload;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_3222;
import java.util.ArrayList;
import java.util.List;

/**
 * 网络通道。客户端接收端在 {@link com.tomc.leveling.LevelingClient}（客户端专属类）。
 */
public final class LevelingNetwork {
    private LevelingNetwork() {
    }

    /** 双端都需要：注册 payload 类型。 */
    public static void registerCommon() {
        PayloadTypeRegistry.playC2S().register(RequestPanelC2SPayload.ID, RequestPanelC2SPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SpendPointC2SPayload.ID, SpendPointC2SPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(CheckPointsC2SPayload.ID, CheckPointsC2SPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(PanelDataS2CPayload.ID, PanelDataS2CPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SpendResultS2CPayload.ID, SpendResultS2CPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(ReminderS2CPayload.ID, ReminderS2CPayload.CODEC);
    }

    /** 服务端接收端。 */
    public static void registerServer() {
        ServerPlayNetworking.registerGlobalReceiver(RequestPanelC2SPayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    class_3222 player = context.player();
                    if (player != null) {
                        sendPanel(player);
                    }
                }));

        ServerPlayNetworking.registerGlobalReceiver(SpendPointC2SPayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    class_3222 player = context.player();
                    if (player != null) {
                        LevelingService.INSTANCE.spendPoint(player, payload.attributeId());
                    }
                }));

        ServerPlayNetworking.registerGlobalReceiver(CheckPointsC2SPayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    class_3222 player = context.player();
                    if (player != null) {
                        sendPointsStatus(player);
                    }
                }));
    }

    public static void sendPanel(class_3222 player) {
        ServerPlayNetworking.send(player, buildPanel(player));
    }

    public static void sendSpendResult(class_3222 player, boolean success, String errorKey) {
        ServerPlayNetworking.send(player, new SpendResultS2CPayload(success, errorKey));
    }

    public static void sendReminder(class_3222 player, int unspentPoints) {
        ServerPlayNetworking.send(player, new ReminderS2CPayload(unspentPoints));
    }

    /** 客户端周期核查的应答：回传当前未使用点数。 */
    public static void sendPointsStatus(class_3222 player) {
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(player.method_5667());
        ServerPlayNetworking.send(player, new ReminderS2CPayload(data.unspentPoints));
    }

    private static PanelDataS2CPayload buildPanel(class_3222 player) {
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(player.method_5667());
        List<AttributeDefView> definitions = new ArrayList<>();
        List<AllocationView> allocations = new ArrayList<>();
        for (AttributeDefinition definition : LevelingRegistry.INSTANCE.definitions().sorted()) {
            definitions.add(new AttributeDefView(
                    definition.attribute(),
                    definition.effectiveDisplayKey(),
                    definition.effectiveDescriptionKey(),
                    definition.cost(),
                    definition.order()
            ));
            PlayerLevelingData.Allocation allocation = data.allocations.get(definition.attribute().toString());
            if (allocation != null) {
                allocations.add(new AllocationView(definition.attribute(), allocation.levels, allocation.spent));
            }
        }
        return new PanelDataS2CPayload(data.highestLevel, data.unspentPoints, definitions, allocations);
    }
}
