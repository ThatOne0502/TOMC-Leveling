package com.tomc.leveling.network.payload;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** 客户端按自身周期向服务端申请核查当前未使用点数。 */
public record CheckPointsC2SPayload() implements class_8710 {
    public static final class_9154<CheckPointsC2SPayload> ID = new class_9154<>(class_2960.method_60655("leveling", "check_points"));

    public static final class_9139<class_9129, CheckPointsC2SPayload> CODEC = class_9139.method_56437(
            (buf, value) -> {
            },
            buf -> new CheckPointsC2SPayload()
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
