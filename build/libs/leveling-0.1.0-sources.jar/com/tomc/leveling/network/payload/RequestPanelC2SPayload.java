package com.tomc.leveling.network.payload;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** 客户端请求打开面板（按 I 键触发）。 */
public record RequestPanelC2SPayload() implements class_8710 {
    public static final class_9154<RequestPanelC2SPayload> ID = new class_9154<>(class_2960.method_60655("leveling", "request_panel"));

    public static final class_9139<class_9129, RequestPanelC2SPayload> CODEC = class_9139.method_56437(
            (buf, value) -> {
            },
            buf -> new RequestPanelC2SPayload()
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
