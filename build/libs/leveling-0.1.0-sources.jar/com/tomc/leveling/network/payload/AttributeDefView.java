package com.tomc.leveling.network.payload;

import net.minecraft.class_2960;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** 面板展示用的属性定义视图（含排序序号与显示/描述译名键）。 */
public record AttributeDefView(class_2960 id, String displayKey, String descriptionKey, int cost, Integer order) {
    public static final class_9139<class_9129, AttributeDefView> STREAM_CODEC = class_9139.method_56437(
            (buf, view) -> {
                class_2960.field_48267.encode(buf, view.id());
                class_9135.field_48554.encode(buf, view.displayKey());
                class_9135.field_48554.encode(buf, view.descriptionKey());
                class_9135.field_48550.encode(buf, view.cost());
                buf.method_52964(view.order() != null);
                if (view.order() != null) {
                    buf.method_10804(view.order());
                }
            },
            buf -> new AttributeDefView(
                    class_2960.field_48267.decode(buf),
                    class_9135.field_48554.decode(buf),
                    class_9135.field_48554.decode(buf),
                    class_9135.field_48550.decode(buf),
                    buf.readBoolean() ? buf.method_10816() : null
            )
    );
}
