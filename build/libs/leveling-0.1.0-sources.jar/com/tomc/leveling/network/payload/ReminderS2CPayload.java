package com.tomc.leveling.network.payload;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** 服务端触发的提醒（事件驱动 + 周期兜底），携带权威的未使用点数。 */
public record ReminderS2CPayload(int unspentPoints) implements class_8710 {
    public static final class_9154<ReminderS2CPayload> ID = new class_9154<>(class_2960.method_60655("leveling", "reminder"));

    public static final class_9139<class_9129, ReminderS2CPayload> CODEC = class_9139.method_56434(
            class_9135.field_48550, ReminderS2CPayload::unspentPoints,
            ReminderS2CPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
