package com.tomc.leveling.network.payload;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** 客户端发送的加点请求。 */
public record SpendPointC2SPayload(class_2960 attributeId) implements class_8710 {
    public static final class_9154<SpendPointC2SPayload> ID = new class_9154<>(class_2960.method_60655("leveling", "spend_point"));

    public static final class_9139<class_9129, SpendPointC2SPayload> CODEC = class_9139.method_56434(
            class_2960.field_48267, SpendPointC2SPayload::attributeId,
            SpendPointC2SPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
