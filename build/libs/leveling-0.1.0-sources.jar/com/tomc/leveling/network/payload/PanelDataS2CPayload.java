package com.tomc.leveling.network.payload;

import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** 服务端推送给客户端的完整面板快照。 */
public record PanelDataS2CPayload(
        int highestLevel,
        int unspentPoints,
        List<AttributeDefView> definitions,
        List<AllocationView> allocations
) implements class_8710 {
    public static final class_9154<PanelDataS2CPayload> ID = new class_9154<>(class_2960.method_60655("leveling", "panel_data"));

    public static final class_9139<class_9129, PanelDataS2CPayload> CODEC = class_9139.method_56905(
            class_9135.field_48550, PanelDataS2CPayload::highestLevel,
            class_9135.field_48550, PanelDataS2CPayload::unspentPoints,
            AttributeDefView.STREAM_CODEC.method_56433(class_9135.method_56363()), PanelDataS2CPayload::definitions,
            AllocationView.STREAM_CODEC.method_56433(class_9135.method_56363()), PanelDataS2CPayload::allocations,
            PanelDataS2CPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
