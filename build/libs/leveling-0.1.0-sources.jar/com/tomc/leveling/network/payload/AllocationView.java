package com.tomc.leveling.network.payload;

import net.minecraft.class_2960;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** 面板展示用的单项属性分配视图。 */
public record AllocationView(class_2960 id, int levels, int spent) {
    public static final class_9139<class_9129, AllocationView> STREAM_CODEC = class_9139.method_56436(
            class_2960.field_48267, AllocationView::id,
            class_9135.field_48550, AllocationView::levels,
            class_9135.field_48550, AllocationView::spent,
            AllocationView::new
    );
}
