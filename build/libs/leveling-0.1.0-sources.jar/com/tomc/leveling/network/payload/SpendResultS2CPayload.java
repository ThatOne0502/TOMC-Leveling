package com.tomc.leveling.network.payload;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** 服务端对加点请求的应答：成功与否 + 失败译名键。 */
public record SpendResultS2CPayload(boolean success, String errorKey) implements class_8710 {
    public static final class_9154<SpendResultS2CPayload> ID = new class_9154<>(class_2960.method_60655("leveling", "spend_result"));

    public static final class_9139<class_9129, SpendResultS2CPayload> CODEC = class_9139.method_56435(
            class_9135.field_48547, SpendResultS2CPayload::success,
            class_9135.field_48554, SpendResultS2CPayload::errorKey,
            SpendResultS2CPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
