package com.tomc.leveling.modifier;

import com.tomc.leveling.Leveling;
import com.tomc.leveling.core.AttributeDefinition;
import com.tomc.leveling.core.LevelingRegistry;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

/**
 * 每项属性只维护一个本模组修饰符，更新时先移除再加。
 */
public final class ModifierApplier {
    private ModifierApplier() {
    }

    public static class_2960 modifierId(class_2960 attributeId) {
        return class_2960.method_60655(Leveling.MOD_ID, "upgrade/" + attributeId.method_12832());
    }

    public static void apply(class_3222 player, class_2960 attributeId, AttributeDefinition definition, int levels) {
        class_1324 instance = instance(player, attributeId);
        if (instance == null) {
            return;
        }
        class_2960 id = modifierId(attributeId);
        instance.method_6200(id);
        if (levels > 0) {
            instance.method_26835(new class_1322(id, definition.totalValue(levels), definition.operation()));
        }
    }

    public static void remove(class_3222 player, class_2960 attributeId) {
        class_1324 instance = instance(player, attributeId);
        if (instance != null) {
            instance.method_6200(modifierId(attributeId));
        }
    }

    public static void removeAll(class_3222 player) {
        for (AttributeDefinition definition : LevelingRegistry.INSTANCE.definitions().all()) {
            remove(player, definition.attribute());
        }
    }

    private static class_1324 instance(class_3222 player, class_2960 attributeId) {
        class_6880<class_1320> holder = class_7923.field_41190.method_10223(attributeId).orElse(null);
        if (holder == null) {
            Leveling.LOGGER.warn("[leveling] Unknown attribute {}", attributeId);
            return null;
        }
        class_1324 instance = player.method_5996(holder);
        if (instance == null) {
            Leveling.LOGGER.warn("[leveling] Player has no attribute instance for {}", attributeId);
        }
        return instance;
    }
}
