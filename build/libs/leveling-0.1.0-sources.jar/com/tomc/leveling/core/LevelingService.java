package com.tomc.leveling.core;

import com.tomc.leveling.config.ServerConfig;
import com.tomc.leveling.data.PlayerLevelingData;
import com.tomc.leveling.item.ModSounds;
import com.tomc.leveling.modifier.ModifierApplier;
import com.tomc.leveling.network.LevelingNetwork;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.class_167;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_2985;
import net.minecraft.class_3222;
import net.minecraft.class_3441;
import net.minecraft.class_8779;

/**
 * 服务端权威核心逻辑：属性点分发、加点、重置、修饰符应用与同步。
 */
public final class LevelingService {
    public static final LevelingService INSTANCE = new LevelingService();

    private LevelingService() {
    }

    /** 登录 / 重生统一入口。 */
    public void onPlayerJoin(class_3222 player) {
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(player.method_5667());
        boolean changed = refundOrphans(data);
        if (changed) {
            LevelingRegistry.INSTANCE.store().save(player.method_5667(), data);
        }
        reapplyAll(player);
        checkDistribution(player);
        sendLoadErrors(player);
        LevelingNetwork.sendPanel(player);
    }

    /** 属性点分发检查：登录、重生、升级共用。 */
    public void checkDistribution(class_3222 player) {
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(player.method_5667());
        int level = player.field_7520;
        if (level > data.highestLevel) {
            int delta = level - data.highestLevel;
            data.unspentPoints += delta;
            data.highestLevel = level;
            LevelingRegistry.INSTANCE.store().save(player.method_5667(), data);
            player.method_5783(ModSounds.LEVELING, 1.0F, 1.0F);
            LevelingNetwork.sendReminder(player, data.unspentPoints); // 事件驱动：立即提醒
            LevelingNetwork.sendPanel(player);
        }
    }

    /** 加点请求。成功返回 null，失败返回错误译名键；同时向客户端发送应答。 */
    public String spendPoint(class_3222 player, class_2960 attributeId) {
        AttributeDefinition definition = LevelingRegistry.INSTANCE.definitions().get(attributeId);
        if (definition == null) {
            LevelingNetwork.sendSpendResult(player, false, "command.leveling.invalid_attribute");
            return "command.leveling.invalid_attribute";
        }
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(player.method_5667());
        if (data.unspentPoints < definition.cost()) {
            LevelingNetwork.sendSpendResult(player, false, "command.leveling.not_enough_points");
            return "command.leveling.not_enough_points";
        }
        data.unspentPoints -= definition.cost();
        PlayerLevelingData.Allocation allocation = data.getAllocation(attributeId);
        allocation.levels += 1;
        allocation.spent += definition.cost();
        LevelingRegistry.INSTANCE.store().save(player.method_5667(), data);
        ModifierApplier.apply(player, attributeId, definition, allocation.levels);
        LevelingNetwork.sendPanel(player);
        LevelingNetwork.sendSpendResult(player, true, "");
        return null;
    }

    /** 孟婆汤效果。 */
    public void applyMengPoSoup(class_3222 player) {
        ServerConfig config = ServerConfig.INSTANCE;
        resetAllocations(player, config.clearRecipesOnUse, config.clearAdvancementsOnUse);
    }

    /** 重置：返还 spent、清空 allocations、移除加成；不影响 highestLevel。 */
    public void resetAllocations(class_3222 player, boolean clearRecipes, boolean clearAdvancements) {
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(player.method_5667());
        for (PlayerLevelingData.Allocation allocation : data.allocations.values()) {
            data.unspentPoints += allocation.spent;
        }
        data.allocations.clear();
        LevelingRegistry.INSTANCE.store().save(player.method_5667(), data);
        ModifierApplier.removeAll(player);
        if (clearRecipes) {
            clearUnlockedRecipes(player);
        }
        if (clearAdvancements) {
            clearAdvancements(player);
        }
        LevelingNetwork.sendPanel(player);
    }

    /** 重新应用所有仍存在的加成（登录、重生、/reload）。 */
    public void reapplyAll(class_3222 player) {
        PlayerLevelingData data = LevelingRegistry.INSTANCE.store().load(player.method_5667());
        for (AttributeDefinition definition : LevelingRegistry.INSTANCE.definitions().all()) {
            ModifierApplier.remove(player, definition.attribute());
        }
        for (Map.Entry<String, PlayerLevelingData.Allocation> entry : data.allocations.entrySet()) {
            class_2960 id = class_2960.method_12829(entry.getKey());
            AttributeDefinition definition = id == null ? null : LevelingRegistry.INSTANCE.definitions().get(id);
            if (definition != null && entry.getValue().levels > 0) {
                ModifierApplier.apply(player, id, definition, entry.getValue().levels);
            }
        }
    }

    /** 当前数据包中不存在的可提升属性：返还 spent、清空该 allocation。 */
    private boolean refundOrphans(PlayerLevelingData data) {
        boolean changed = false;
        Iterator<Map.Entry<String, PlayerLevelingData.Allocation>> iterator = data.allocations.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, PlayerLevelingData.Allocation> entry = iterator.next();
            class_2960 id = class_2960.method_12829(entry.getKey());
            if (id == null || LevelingRegistry.INSTANCE.definitions().get(id) == null) {
                data.unspentPoints += entry.getValue().spent;
                iterator.remove();
                changed = true;
            }
        }
        return changed;
    }

    private void sendLoadErrors(class_3222 player) {
        List<String> errors = LevelingRegistry.INSTANCE.definitions().getLoadErrors();
        if (errors.isEmpty()) {
            return;
        }
        player.method_64398(class_2561.method_43471("message.leveling.load_error_header"));
        for (String error : errors) {
            player.method_64398(class_2561.method_43470(error));
        }
    }

    private void clearUnlockedRecipes(class_3222 player) {
        class_3441 book = player.method_14253();
        book.method_14900(player.method_51469().method_8503().method_3772().method_8126(), player);
    }

    private void clearAdvancements(class_3222 player) {
        class_2985 advancements = player.method_14236();
        for (class_8779 holder : player.method_51469().method_8503().method_3851().method_12893()) {
            class_167 progress = advancements.method_12882(holder);
            for (String criterion : progress.method_734()) {
                advancements.method_12883(holder, criterion);
            }
        }
    }
}
